module com.mycompany.agenceavion {
    requires javafx.controls;
    requires java.sql;
	requires javafx.graphics;
    exports com.mycompany.agenceavion;
}
